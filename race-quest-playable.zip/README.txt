Ekstrak ZIP lalu buka RACE-QUEST-Kucing-Blocky.html di browser. Semua aset tertanam. Garasi menyediakan Mobil + Karakter dan Close-up Karakter; geser untuk memutar, scroll atau pinch untuk zoom.
